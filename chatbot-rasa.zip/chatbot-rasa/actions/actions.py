import mysql.connector
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher

# Hàm kết nối MySQL
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Nếu có mật khẩu thì điền vào đây
        database="quanlycoffee",
        charset='utf8'
    )

# Hành động: Sản phẩm rẻ nhất
class ActionCheapestProduct(Action):
    def name(self):
        return "action_cheapest_product"

    def run(self, dispatcher, tracker, domain):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT tensanpham, giasp FROM tbl_sanpham ORDER BY CAST(giasp AS UNSIGNED) ASC LIMIT 1")
        result = cursor.fetchone()
        conn.close()

        if result:
            tensp = result[0]
            giasp = int(result[1])  # chuyển từ chuỗi sang số
            dispatcher.utter_message(
                text=f"Sản phẩm rẻ nhất là: {tensp} với giá {giasp:,} VNĐ"
            )
        else:
            dispatcher.utter_message(text="Không tìm thấy sản phẩm.")
        return []

# Hành động: Sản phẩm đắt nhất
class ActionMostExpensiveProduct(Action):
    def name(self):
        return "action_most_expensive_product"

    def run(self, dispatcher, tracker, domain):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT tensanpham, giasp FROM tbl_sanpham ORDER BY CAST(giasp AS UNSIGNED) DESC LIMIT 1")
        result = cursor.fetchone()
        conn.close()

        if result:
            tensp = result[0]
            giasp = int(result[1])  # chuyển từ chuỗi sang số
            dispatcher.utter_message(
                text=f"Sản phẩm đắt nhất là: {tensp} với giá {giasp:,} VNĐ"
            )
        else:
            dispatcher.utter_message(text="Không tìm thấy sản phẩm.")
        return []

# Hành động: Các sản phẩm dưới 500k
class ActionProductsUnder500k(Action):
    def name(self):
        return "action_products_under_500k"

    def run(self, dispatcher, tracker, domain):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT tensanpham, giasp FROM tbl_sanpham WHERE CAST(giasp AS UNSIGNED) < 500000")
        results = cursor.fetchall()
        conn.close()

        if results:
            message = "Các sản phẩm dưới 500k:\n"
            for row in results:
                tensp = row[0]
                giasp = int(row[1])  # chuyển từ chuỗi sang số
                message += f"- {tensp}: {giasp:,} VNĐ\n"
            dispatcher.utter_message(text=message.strip())
        else:
            dispatcher.utter_message(text="Không có sản phẩm nào dưới 500k.")
        return []

# Bán chạy nhất
class ActionBestSeller(Action):
    def name(self):
        return "action_best_seller"

    def run(self, dispatcher, tracker, domain):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT tensanpham, soluongban FROM tbl_sanpham ORDER BY CAST(soluongban AS UNSIGNED) DESC LIMIT 1")
        result = cursor.fetchone()
        conn.close()

        if result:
            dispatcher.utter_message(text=f"Sản phẩm bán chạy nhất là: {result[0]} với {result[1]} lượt bán.")
        else:
            dispatcher.utter_message(text="Không tìm thấy sản phẩm bán chạy.")
        return []

# Khuyến mãi
class ActionPromotionProducts(Action):
    def name(self):
        return "action_promotion_products"

    def run(self, dispatcher, tracker, domain):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.tensanpham, k.phantramgiam 
            FROM tbl_sanpham s
            JOIN tbl_khuyenmai k ON s.id_sanpham = k.id_sanpham
        """)
        results = cursor.fetchall()
        conn.close()

        if results:
            message = "Các sản phẩm đang khuyến mãi:\n"
            for row in results:
                message += f"- {row[0]}: Giảm {row[1]}%\n"
            dispatcher.utter_message(text=message.strip())
        else:
            dispatcher.utter_message(text="Hiện tại không có sản phẩm nào đang khuyến mãi.")
        return []

# Sản phẩm tốt nhất 
class ActionBestProduct(Action):
    def name(self):
        return "action_best_product"

    def run(self, dispatcher, tracker, domain):
        conn = get_db_connection()
        cursor = conn.cursor()

        query = """
            SELECT sp.tensanpham, AVG(bl.rating) AS diem_tb
            FROM tbl_binhluan bl
            JOIN tbl_sanpham sp ON bl.id_sanpham = sp.id_sanpham
            GROUP BY bl.id_sanpham
            ORDER BY diem_tb DESC
            LIMIT 1
        """
        cursor.execute(query)
        result = cursor.fetchone()
        conn.close()

        if result:
            dispatcher.utter_message(
                text=f"Sản phẩm tốt nhất là: {result[0]} với đánh giá trung bình {round(result[1], 1)}/5."
            )
        else:
            dispatcher.utter_message(text="Không tìm thấy sản phẩm tốt nhất.")
        return []

    
# Sản phẩm yêu thích nhất
class ActionMostFavoritedProduct(Action):
    def name(self): return "action_most_favorited_product"

    def run(self, dispatcher, tracker, domain):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT sp.tensanpham, COUNT(*) AS so_luot_yeu_thich
            FROM tbl_yeuthich yt
            JOIN tbl_sanpham sp ON yt.product_id = sp.id_sanpham
            GROUP BY yt.product_id
            ORDER BY so_luot_yeu_thich DESC
            LIMIT 1
        """)
        result = cursor.fetchone()
        conn.close()

        if result:
            dispatcher.utter_message(text=f"Sản phẩm được yêu thích nhất là: {result[0]} với {result[1]} lượt yêu thích.")
        else:
            dispatcher.utter_message(text="Không tìm thấy sản phẩm được yêu thích.")
        return []