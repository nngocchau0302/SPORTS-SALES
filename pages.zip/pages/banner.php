<div class="banner">
    <div class="slide">  
    
          <img src="/images/astrox88-sd-key.webp" alt="LGcoffee" >
          <img src="https://cdn.shopvnb.com/img/1920x640/uploads/slider/banner-sale-12_1695182579.webp" alt="LGcoffee" >
          <img src="https://cdn.shopvnb.com/img/1920x640/uploads/slider/ynx-eclp-banner_1695178004.webp" alt="LGcoffee" >
          <img src="/images/BannerWeb-2.png" alt="LGcoffee" >
    </div>

      
        
      </div> 