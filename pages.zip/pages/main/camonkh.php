

<div class="wrapper_sanpham">
    <div class="hinhanh_sanpham"
        style="float: left;
    width: 65%;
     height:auto;
    text-align: center;
    margin-left: 200px;
    ">

        <img width="90%" src="/images/camon2.png">
    </div>


    <!-- <form method="POST" action="">
        <div class="chitiet_sanpham"
            style="float: right;
    width: 40%;">
            <img width="90%" src="/images/camon2.png">

        </div>
    </form> -->
</div>
<style>
    .wrapper {
        height: 500px;
    }

    .wrapper_sanpham {
        margin-top: 20px;
    }
</style>