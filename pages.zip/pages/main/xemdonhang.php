<?php
$code = $_GET['code'];

$sql_lietke_dh = "SELECT * FROM tbl_cart_details, tbl_sanpham 
                  WHERE tbl_cart_details.id_sanpham = tbl_sanpham.id_sanpham 
                  AND tbl_cart_details.code_cart = '" . $code . "' 
                  ORDER BY tbl_cart_details.id_cart_details ASC";

$query_lietke_dh = mysqli_query($mysqli, $sql_lietke_dh);

// Kiểm tra kết nối
if (!$mysqli) {
    echo "Lỗi kết nối cơ sở dữ liệu: " . mysqli_connect_error();
    exit();
}

// Kiểm tra truy vấn SQL
if ($query_lietke_dh === false) {
    echo "Lỗi truy vấn SQL: " . mysqli_error($mysqli);
    exit();
}

// Kiểm tra số lượng kết quả trả về
$num_rows = mysqli_num_rows($query_lietke_dh);
if ($num_rows == 0) {
    echo "Không tìm thấy đơn hàng với mã: " . $code;
    exit();
}
// Kiểm tra đơn hàng có vợt cầu lông (id_danhmuc = 1)
$has_racket = false;
foreach ($query_lietke_dh as $check) {
    if ($check['id_danhmuc'] == 1) {
        $has_racket = true;
        break;
    }
}
// Reset con trỏ kết quả
mysqli_data_seek($query_lietke_dh, 0);
?>

<body class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="w-full max-w-6xl bg-white p-10 rounded-lg shadow-2xl">
        <h1 class="text-2xl font-bold mb-8 text-center text-gray-800">Chi tiết đơn hàng</h1>
        <table style="width:100%" border="1" class="w-full border-collapse">
            <thead>
                <tr class="bg-gray-100 text-gray-800">
                    <th class="border border-gray-300 p-2 text-center">Id</th>
                    <th class="border border-gray-300 p-2 text-center">Mã đơn hàng</th>
                    <th class="border border-gray-300 p-2 text-center">Tên sản phẩm</th>
                    <?php if ($has_racket): ?>
                        <th class="border border-gray-300 p-2 text-center">Số seri</th>
                    <?php endif; ?>
                    <th class="border border-gray-300 p-2 text-center">Số lượng</th>
                    <th class="border border-gray-300 p-2 text-center">Đơn giá</th>
                    <th class="border border-gray-300 p-2 text-center">Thành tiền</th>

                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                $tongtien = 0;
                mysqli_data_seek($query_lietke_dh, 0);
                while ($row = mysqli_fetch_array($query_lietke_dh)) {
                    $i++;
                    $thanhtien = $row['giasp'] * $row['soluongmua'];
                    $tongtien += $thanhtien;
                ?>
                    <tr class="hover:bg-gray-100">
                        <td class="border border-gray-300 p-2 text-center"><?php echo $i ?></td>
                        <td class="border border-gray-300 p-2 text-center"><?php echo $row['code_cart'] ?></td>
                        <td class="border border-gray-300 p-2 text-center"><?php echo $row['tensanpham'] ?></td>
                        <?php if ($has_racket): ?>
                            <?php if ($row['id_danhmuc'] == 1): ?>
                                <?php
                                // Truy vấn số seri từ bảng tbl_serial_racket
                                $seri_sql = "SELECT seri FROM tbl_serial_racket 
                                 WHERE code_cart = '{$row['code_cart']}' AND id_sanpham = {$row['id_sanpham']}";
                                $seri_result = mysqli_query($mysqli, $seri_sql);
                                $seri_arr = [];
                                while ($seri_row = mysqli_fetch_assoc($seri_result)) {
                                    $seri_arr[] = $seri_row['seri'];
                                }
                                ?>
                                <td class="border border-gray-300 p-2 text-center">
                                    <?php echo !empty($seri_arr) ? implode(', ', $seri_arr) : 'Chưa có'; ?>
                                </td>
                            <?php else: ?>
                                <td class="border border-gray-300 p-2 text-center">-</td>
                            <?php endif; ?>
                        <?php endif; ?>
                        <td class="border border-gray-300 p-2 text-center"><?php echo $row['soluongmua'] ?></td>
                        <td class="border border-gray-300 p-2 text-center"><?php echo number_format($row['giasp'], 0, ',', '.') . 'vnd' ?></td>
                        <td class="border border-gray-300 p-2 text-center"><?php echo number_format($thanhtien, 0, ',', '.') . 'vnd' ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <div class="mt-4 p-2 bg-gray-300 text-right rounded-lg">
            <span class="font-bold">Tổng tiền: <?php echo number_format($tongtien, 0, ',', '.') . 'vnđ' ?></span>
        </div>

        <!-- ========== BẢO HÀNH ========== -->
       <?php
$sql_baohanh = "
SELECT 
    sp.id_sanpham,
    sp.tensanpham, 
    sp.masp,
    sp.baohanh, 
    c.cart_date, 
    cd.soluongmua, 
    c.code_cart,
    dm.tendanhmuc,
    dm.id_danhmuc
FROM tbl_cart_details AS cd
JOIN tbl_cart AS c ON cd.code_cart = c.code_cart
JOIN tbl_sanpham AS sp ON cd.id_sanpham = sp.id_sanpham
JOIN tbl_danhmuc AS dm ON sp.id_danhmuc = dm.id_danhmuc
WHERE cd.code_cart = '$code'
";
$query_baohanh = mysqli_query($mysqli, $sql_baohanh);

// Kiểm tra xem có sản phẩm là vợt cầu lông không
$has_racket = false;
$rows_baohanh = [];
while ($row = mysqli_fetch_assoc($query_baohanh)) {
    $rows_baohanh[] = $row;
    if ($row['id_danhmuc'] == 1) {
        $has_racket = true;
    }
}

if ($has_racket) {
    echo "<h2 class='text-2xl font-bold mt-10 mb-4 text-center text-gray-800'>Tình trạng bảo hành sản phẩm</h2>";
    echo "<table class='w-full border border-collapse text-center text-sm'>";
    echo "<thead class='bg-gray-200'>
        <tr>
            <th class='border p-2'>Tên sản phẩm</th>
            <th class='border p-2'>Danh mục</th>
            <th class='border p-2'>Số Seri</th>
            <th class='border p-2'>Ngày mua</th>
            <th class='border p-2'>Thời gian BH</th>
            <th class='border p-2'>Ngày hết BH</th>
            <th class='border p-2'>Trạng thái</th>
        </tr>
      </thead><tbody>";

    foreach ($rows_baohanh as $row) {
        $ngay_mua = date_create($row['cart_date']);
        $baohanh_thang = intval($row['baohanh']);
        $ngay_het_bh = date_create($row['cart_date']);
        date_add($ngay_het_bh, date_interval_create_from_date_string("$baohanh_thang months"));

        $today = new DateTime();
        $status = ($today <= $ngay_het_bh)
            ? "<span class='text-green-600 font-medium'>Còn bảo hành</span>"
            : "<span class='text-red-600 font-medium'>Hết bảo hành</span>";

        // Chỉ hiện số seri nếu là vợt cầu lông
        $seri_str = "-";
        if ($row['id_danhmuc'] == 1) {
            $seri_sql = "SELECT sr.seri 
                         FROM tbl_serial_racket AS sr 
                         JOIN tbl_seri AS s ON sr.seri = s.seri 
                         WHERE sr.code_cart = '{$row['code_cart']}' 
                         AND s.id_sanpham = {$row['id_sanpham']}";
            $seri_query = mysqli_query($mysqli, $seri_sql);
            $seri_arr = [];
            while ($seri_row = mysqli_fetch_assoc($seri_query)) {
                $seri_arr[] = $seri_row['seri'];
            }
            $seri_str = !empty($seri_arr) ? implode(', ', $seri_arr) : "-";
        }

        echo "<tr class='hover:bg-gray-50'>
            <td class='border p-2'>{$row['tensanpham']}</td>
            <td class='border p-2'>{$row['tendanhmuc']}</td>
            <td class='border p-2'>$seri_str</td>
            <td class='border p-2'>" . date_format($ngay_mua, 'd/m/Y') . "</td>
            <td class='border p-2'>{$row['baohanh']} tháng</td>
            <td class='border p-2'>" . date_format($ngay_het_bh, 'd/m/Y') . "</td>
            <td class='border p-2'>$status</td>
          </tr>";
    }

    echo "</tbody></table>";
}
?>

    </div>
</body>